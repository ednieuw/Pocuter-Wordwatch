var struct_pocuter_w_i_f_i_1_1wifi_credentials =
[
    [ "password", "d2/dc4/struct_pocuter_w_i_f_i_1_1wifi_credentials.html#a3c755de5d6dae34b4fe22d9d233f1f0b", null ],
    [ "ssid", "d2/dc4/struct_pocuter_w_i_f_i_1_1wifi_credentials.html#a63f480852d8d0b69b76fb14cb05c36b0", null ]
];