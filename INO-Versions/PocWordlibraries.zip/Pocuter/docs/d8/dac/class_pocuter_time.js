var class_pocuter_time =
[
    [ "pocuterTimezone", "dc/d6c/struct_pocuter_time_1_1pocuter_timezone.html", "dc/d6c/struct_pocuter_time_1_1pocuter_timezone" ],
    [ "TIMEERROR", "d8/dac/class_pocuter_time.html#aac969c3d099e2a323ee0917afd6a50cb", [
      [ "TIMEERROR_OK", "d8/dac/class_pocuter_time.html#aac969c3d099e2a323ee0917afd6a50cbae9defbc26905269299f8704f543d5cf6", null ],
      [ "TIMEERROR_FAILED", "d8/dac/class_pocuter_time.html#aac969c3d099e2a323ee0917afd6a50cba7c302b272847cc8ae866ceb605eb8cc7", null ],
      [ "TIMEERROR_UNKNOWN", "d8/dac/class_pocuter_time.html#aac969c3d099e2a323ee0917afd6a50cba1eae185f37c5ea7d7911765b5ff7a170", null ]
    ] ],
    [ "getAllTimezones", "d8/dac/class_pocuter_time.html#a4bbb69edc65f2ab480b5c0b9ff5c03f5", null ],
    [ "getCurrentTimezone", "d8/dac/class_pocuter_time.html#a90c9abc66f51d094bae63bf393a4b007", null ],
    [ "getGMTTime", "d8/dac/class_pocuter_time.html#ac72c12c8c475687bc837e4bc8aecae47", null ],
    [ "getLocalTime", "d8/dac/class_pocuter_time.html#a8a357b44161ae8104f19250ed48c3cce", null ],
    [ "getTimeServer", "d8/dac/class_pocuter_time.html#ac1988e3de62f0d4ead9c7a1b956c4c35", null ],
    [ "isTimeServer", "d8/dac/class_pocuter_time.html#a71445aa57c87cfab12c466133eaf9e89", null ],
    [ "setLocalTime", "d8/dac/class_pocuter_time.html#a37e7bf46045af295d60eebef6003301c", null ],
    [ "setTimeServer", "d8/dac/class_pocuter_time.html#ab35ecfd6bfdf86682e2397ece6a3a9d6", null ],
    [ "setTimeServer", "d8/dac/class_pocuter_time.html#af22ef1642eff679a14abb708086c19d3", null ],
    [ "setTimezone", "d8/dac/class_pocuter_time.html#a0a02b59e098948df15a50231334abc29", null ],
    [ "c_tz", "d8/dac/class_pocuter_time.html#aae61077589c0c918578b4489adb3bb04", null ]
];