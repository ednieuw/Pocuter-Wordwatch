var class_pocuter_h_t_t_p =
[
    [ "HTTPERROR", "d6/dc4/class_pocuter_h_t_t_p.html#ac55d9f750eb748036c5010b0004ccfe3", [
      [ "HTTPERROR_OK", "d6/dc4/class_pocuter_h_t_t_p.html#ac55d9f750eb748036c5010b0004ccfe3a8996df08df9b2323dfe2f1837c946ab4", null ],
      [ "HTTPERROR_CONNECT_FAILED", "d6/dc4/class_pocuter_h_t_t_p.html#ac55d9f750eb748036c5010b0004ccfe3ad9ffbdcfc61967cf13eda0146fe96b62", null ],
      [ "HTTPERROR_NO_MEMORY", "d6/dc4/class_pocuter_h_t_t_p.html#ac55d9f750eb748036c5010b0004ccfe3ab0e224580d1c4f008b8dd1eb5dbf69d5", null ],
      [ "HTTPERROR_FILE_OPEN_FAILED", "d6/dc4/class_pocuter_h_t_t_p.html#ac55d9f750eb748036c5010b0004ccfe3a96bba5abd7a9d526aa2712273acd0600", null ],
      [ "HTTPERROR_DOWNLOAD_FAILED", "d6/dc4/class_pocuter_h_t_t_p.html#ac55d9f750eb748036c5010b0004ccfe3ab1e3ad44f226155b4acd641364149c12", null ],
      [ "HTTPERROR_MORE_STEPS", "d6/dc4/class_pocuter_h_t_t_p.html#ac55d9f750eb748036c5010b0004ccfe3a8bd77387b2b135e40c30107ff686d335", null ],
      [ "HTTPERROR_UNKNOWN", "d6/dc4/class_pocuter_h_t_t_p.html#ac55d9f750eb748036c5010b0004ccfe3af760846487d822e31680d918dc65574e", null ]
    ] ],
    [ "downloadFile", "d6/dc4/class_pocuter_h_t_t_p.html#ae8a6ff33381c6c99558d9773d6c10bff", null ],
    [ "getResponse", "d6/dc4/class_pocuter_h_t_t_p.html#a7aa4eb27ffad09e8c50cf1e65e7595bb", null ]
];