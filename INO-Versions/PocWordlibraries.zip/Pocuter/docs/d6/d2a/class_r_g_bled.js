var class_r_g_bled =
[
    [ "LEDERROR", "d6/d2a/class_r_g_bled.html#a97dcd675f2fec2253b0d138ab90db786", [
      [ "LEDERROR_OK", "d6/d2a/class_r_g_bled.html#a97dcd675f2fec2253b0d138ab90db786ab7cbf06137fa6b1de6035e0323d1e1fe", null ],
      [ "LEDERROR_FAILURE", "d6/d2a/class_r_g_bled.html#a97dcd675f2fec2253b0d138ab90db786a854ff54147c20f65ce9a79dd6a9021df", null ]
    ] ],
    [ "setRGB", "d6/d2a/class_r_g_bled.html#a46ec96d3eb15e760cf0f87d24809a25a", null ]
];